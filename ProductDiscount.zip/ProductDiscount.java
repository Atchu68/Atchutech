package onlineclasses;
import java.util.Scanner;

public class ProductDiscount{
	public static void main(String[]args) {
		Scanner scan = new Scanner(System.in);
		double quantity,price,amount,discount;
		System.out.println("Enter the quantity of the product");
		quantity = scan.nextDouble();
		System.out.println("Enter the price of the product");
		price = scan.nextDouble();
		amount = quantity*price;
		if(amount>5000) {
			discount = amount*0.1;
			amount = amount-discount;
			System.out.println("The total price of the product is : "+amount);
		}
	}
}