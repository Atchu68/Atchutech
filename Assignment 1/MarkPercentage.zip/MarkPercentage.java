package onlineclasses;

import java.util.Scanner;
public class  MarkPercentage {
	
	public static void main (String[] args){
		int tam,eng,maths,sci,soc;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Ener the marks of 5 subjects;");
		System.out.print("tamil");
		tam=scanner.nextInt();
        System.out.print("english");
		eng=scanner.nextInt();
        System.out.print("maths");
		maths=scanner.nextInt();
        System.out.print("science");
		sci=scanner.nextInt();
        System.out.print("social");
		soc=scanner.nextInt();
        int total =tam+eng+maths+sci+soc;
        float percentage=total/5;
        System.out.println("percentage scored :"+percentage);
        if((percentage>=60)&&(percentage<=100)){
              System.out.println("First Division");
         }
        else if((percentage>=50)&&(percentage<=60)){
             System.out.println("Second Division");
        }
        else if((percentage>=40)&&(percentage<=50)){
              System.out.println("Third Division");
         }
        else if((percentage>=0)&&(percentage<=40)){
              System.out.println("Fail");
        }
        else{
              System.out.println("Invalid Input");
        }
    }
}