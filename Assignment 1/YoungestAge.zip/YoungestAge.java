package onlineclasses;

import java.util.Scanner;

public class YoungestAge {
	public static void main (String[] args){ 
		Scanner scanner=new Scanner(System.in);
		System.out.println("Entre the age of ram");
		int ram_age = scanner.nextInt();
		System.out.println("Entre the age of subha");
		int subha_age = scanner.nextInt();
		System.out.println("Entre the age of ajay");
		int ajay_age = scanner.nextInt();
		if(ram_age<subha_age && ram_age<ajay_age) {
			System.out.println("The youngest one is Ram");
		}
		else if(subha_age<ram_age && subha_age<ajay_age) {
			System.out.println("The youngest one is Subha");
		}
		else{
			System.out.println("The youngest one is Ajay");
		}
	}
}