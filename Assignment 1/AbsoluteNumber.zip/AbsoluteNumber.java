package onlineclasses;

import java.util.Scanner;
public class AbsoluteNumber {
	public static void main (String[] args){ 
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the number:");
		 int num= scanner.nextInt();
		 
		 if(num<0){ 
			int abs=-num;
		   	System.out.println("the absolute value of "+num+ " is : " +abs);
		 }
		 else{
          	System.out.println("the absolute value of "+num+" is : " +num);
		 }
  	}
}