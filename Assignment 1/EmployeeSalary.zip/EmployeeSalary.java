package onlineclasses;

import java.util.Scanner;

public class EmployeeSalary {
	public static void main (String[] args){ 
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the Salary amount");
		float salary = scanner.nextFloat();
		float hra,da,gross_salary;
		if(salary<1500) {
			hra = salary/10;
			da = salary*(90/100);
			gross_salary = hra+da+salary;
			System.out.println("The HRA : "+hra);
			System.out.println("The DA : "+da);
			System.out.println("The Gross Salary : "+gross_salary);
		}
		else {
			hra = 500;
			da = salary*(98/100);
			gross_salary = hra+da+salary;
			System.out.println("The HRA : "+hra);
			System.out.println("The DA : "+da);
			System.out.println("The Gross Salary : "+gross_salary);
		}
	}
}