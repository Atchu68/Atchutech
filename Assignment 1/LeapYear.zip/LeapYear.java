package onlineclasses;

import java.util.Scanner;

public class LeapYear {
	public static void main (String[] args){ 
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the Year");
		int year = scanner.nextInt();
		if(year%4==0) {
			System.out.println("It's a leap year");
		}
		else if(year%100==0) {
			System.out.println("It's a century year");
		}
		else {
			System.out.println("It's not a leap year");
		}
	}
}