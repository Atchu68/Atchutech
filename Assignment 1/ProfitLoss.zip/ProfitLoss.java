package onlineclasses;

import java.util.Scanner;

public class ProfitLoss {
	public static void main (String[] args){ 
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the cost price");
		int costPrice = scanner.nextInt();
		System.out.println("Enter selling price");
		int sellingPrice = scanner.nextInt();
		int profit,loss;
		if(sellingPrice>costPrice) {
			profit = sellingPrice-costPrice;
			System.out.println("The Profit is : "+profit);
		}
		else if(sellingPrice<costPrice) {
			loss = costPrice-sellingPrice;
			System.out.println("The loss is : "+loss);
		}
		else {
			System.out.println("No profit....No loss");
		}
	}
}