package onlineclasses;

import java.util.Scanner;

public class TelephoneBill {
	public static void main (String[] args){ 
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Total number of calls");
		int calls = scanner.nextInt();
		double billingAmount = 0;
		if(calls>0 && calls<=100) {
			billingAmount = 200;
		}
		else if(calls>100 && calls<=150) {
			calls-=100;
			billingAmount =200+(50*0.6)+(calls*0.5); 
		}
		else if(calls>200) {
			calls-=200;
			billingAmount =200+(50*0.6)+(50*0.5)+(calls*0.4);
		}
		else {
			billingAmount=0;
			System.out.println("Invalid input");
		}
		System.out.println("The billingAmount Payable is : "+billingAmount);
	}
}