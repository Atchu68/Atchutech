package onlineclasses;

import java.util.Scanner;

public class ValidTriangle {
	public static void main (String[] args){ 
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the 1st Triangle");
		int triangle1 = scanner.nextInt();
		System.out.println("Enter the 2nd Triangle");
		int triangle2 = scanner.nextInt();
		System.out.println("Enter the 3rd Triangle");
		int triangle3 = scanner.nextInt();
		if(triangle1+triangle2+triangle3 == 180) {
			System.out.println("It's a valid Triangle");
		}
		else {
			System.out.println("It's not a valid Triangle");
		}
	}
}