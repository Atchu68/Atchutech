
		// TODO Auto-generated method stub
package onlineclasses;

public class Pattern2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int  i, count=3;
 	   for(int k=1;k<=3;k++)
 	   {
 	      for( i=count;i>0;i--)
 	      {
 	           System.out.print(i);
 	          if(i==1)
 	            {
 	            	for(int j=i+1;j<=count;j++)
 	            	  {
 	            	  	
                               System.out.print(j);
                             }}}
                    System.out.println("");
                    count--;
}
	}

}
