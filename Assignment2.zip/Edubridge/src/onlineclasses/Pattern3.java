package onlineclasses;

public class Pattern3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int k=3;k>=1;k--)
   	   {
   	      for(int i=1;i<=k;i++)
   	      System.out.print(i);
   	      for(int j=k-1;j>=1;j--)
   	      System.out.print(j);
   	      System.out.println("");
   	      
}}
	}


